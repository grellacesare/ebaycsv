Questa cartella deve essere FUORI dal webroot pubblico reale.
Se csvstudio si trova in public_html/csvstudio, collocare csvstudio-data
accanto a public_html, non al suo interno. private_html può essere pubblico.
Il programma creerà qui la chiave iniziale, le credenziali e l'archivio.
Non pubblicare questa cartella, i suoi backup o la chiave di installazione.
